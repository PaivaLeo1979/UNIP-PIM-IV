// 3016-50_SEI_DS_0720_R_20202_01: PROJETO INTEGRADO MULTIDISCIPLINAR IV
// Programa de Cadastro de Pacientes COVID19
// Alunos:  Ant�nio Juv�ncio de Oliveira Filho - RA:2088107
//          Leonardo Aparecido de Paiva - RA:0550487
//          Pamela dos Santos Silva � RA:2096092
//          Fabio Luciano Viana � RA: 0581014

//UNIVERSIDADE PAULISTA � UNIP EAD

//Projeto Integrado Multidisciplinar
//Curso Superior de Tecnologia em Analise e Desenvolvimento de Sistemas



#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <locale.h>
#include <string.h>

typedef struct datadg DATADG;
struct datadg{
    int diag;
    int mesg;
    int anog;
};

typedef struct datanasc DATANASC;
struct datanasc{
    int dian;
    int mesn;
    int anon;
};

typedef struct paciente PACIENTE;
struct paciente{
    DATADG dtdiag;
    DATANASC dtnasc;
    char nome[50];
    char idade[3];
    char email[30];
    char cpf[14];
    char fone[15];
    char endereco[50];
    char bairro[20];
    char cep[12];
    char cidade[20];
    char uf[3];
    char comorbidade[50];

};

void Login();
void cabecalho();
void AddPaciente();
void RemoveReg();
void PesquisarPac();
void LstPaciente();
void RelatorioRsk();


main(){
    setlocale(LC_ALL, "Portuguese");
    system("color 1F");
    int opcao;
    Login();
    do{

        cabecalho();

        printf("\n                 [ 1 ] - Cadastrar Paciente\n");
        printf("\n                 [ 2 ] - Remover Registro\n");
        printf("\n                 [ 3 ] - Pesquisar Paciente\n");
        printf("\n                 [ 4 ] - Listar Pacientes\n");
        printf("\n                 [ 5 ] - Relat�rio de Grupo de Risco\n");
        printf("\n                 [ 6 ] - Sair\n\n\n");
        printf(" ------------------------------------------------------------\n\n");
        printf("                Selecione a Op��o : "      );
        scanf("%d",  &opcao);

        switch(opcao) {
            case 1:
                AddPaciente();
            break;

            case 2:
                RemoveReg();
            break;

            case 3:
                PesquisarPac();
            break;

            case 4:
                 LstPaciente();
            break;

            case 5:
                RelatorioRsk();
            break;

            case 6:
            printf("\n\nPARAB�NS!!! Obrigado por realizar o cadastro do paciente.\n");
            getch();
            break;

            default:
            printf("\n\nA op��o seleciona est� INV�LIDA!!!\n");
            getch();
            break;

        }
            }while(opcao != 6);
}

void cabecalho(){
    system("cls");
    printf("\n\n\t\t+++ HOSPITAL DE CAMPANHA - UNIP +++");
    printf("\n ------------------------------------------------------------\n");
    printf("\t\tREGISTRO DE PACIENTE COM COVID-19\n");
    printf(" ------------------------------------------------------------\n\n");
}

void AddPaciente(){

    FILE* CadArquivo;
    PACIENTE pac;

   CadArquivo = fopen("cadpaciente.txt", "ab");
   if(CadArquivo == NULL){
    printf("ATEN��O !!! Problemas na abertura do registro ou cadastro vazio...\n\n");
    getch();
   }
   else{
    do{
        cabecalho();
        printf("\nData do Diagn�stico: ");
        scanf("%d %d %d",&pac.dtdiag.diag, &pac.dtdiag.mesg, &pac.dtdiag.anog);

        fflush(stdin);
        printf("\nDigite o Nome: ");
        gets(pac.nome);

        fflush(stdin);
        printf("\nData de Nascimento: ");
        scanf("%d %d %d",&pac.dtnasc.dian, &pac.dtnasc.mesn, &pac.dtnasc.anon);

        fflush(stdin);
        printf("\nDigite a Idade: ");
        scanf("%s", &pac.idade);
        //gets(pac.idade);

        fflush(stdin);
        printf("\nDigite E-mail: ");
        gets(pac.email);

        fflush(stdin);
        printf("\nDigite o CPF: ");
        gets(pac.cpf);

        fflush(stdin);
        printf("\nDigite o Telefone: ");
        gets(pac.fone);

        fflush(stdin);
        printf("\nDigite endere�o: ");
        gets(pac.endereco);

        fflush(stdin);
        printf("\nDigite o Bairro: ");
        gets(pac.bairro);

        fflush(stdin);
        printf("\nDigite CEP: ");
        gets(pac.cep);

        fflush(stdin);
        printf("\nDigite a Cidade: ");
        gets(pac.cidade);

        fflush(stdin);
        printf("\nDigite a UF: ");
        gets(pac.uf);

        fflush(stdin);
        printf("\nO paciente possui alguma comordidade, relate quais por favor: ");
        gets(pac.comorbidade);


        fwrite(&pac, sizeof(PACIENTE), 1, CadArquivo);

        printf("\n\nDeseja continuar mais cadastros(s/n)?");

    }while(getche() == 's');
    fclose(CadArquivo);
   }
}

void LstPaciente(){

    FILE* CadArquivo;
    PACIENTE pac;

   CadArquivo = fopen("cadpaciente.txt", "rb");

   cabecalho();
   if(CadArquivo == NULL){
    printf("ATEN��O !!! Problemas na abertura do registro ou cadastro vazio...\n\n");
    getch();
   }
   else{

    while(fread(&pac, sizeof(PACIENTE), 1,CadArquivo) == 1){
        printf("Data Diagnostico: %d/%d/%d \n", pac.dtdiag.diag, pac.dtdiag.mesg, pac.dtdiag.anog);
        printf("Nome: %s\n",pac.nome);
        printf("Data de Nascimento: %d/%d/%d \n", pac.dtnasc.dian, pac.dtnasc.mesn, pac.dtnasc.anon);
        printf("Idade: %s \n", pac.idade);
        printf("Email: %s \n", pac.email);
        printf("CPF: %s\n", pac.cpf);
        printf("Telefone: %s\n", pac.fone);
        printf("Endere�o: %s\n", pac.endereco);
        printf("Bairro: %s\n", pac.bairro);
        printf("CEP: %s\n", pac.cep);
        printf("Cidade: %s\n", pac.cidade);
        printf("UF: %s\n", pac.uf);
        printf("Comorbidades: %s\n", pac.comorbidade);
        printf("\n------------------------------------------------------------\n\n");
    }

   }
   fclose(CadArquivo);
   getch();
}

void RemoveReg(){

    FILE* CadArquivo;
    FILE* temp;
    PACIENTE pac;
    char nome[30];

   CadArquivo = fopen("cadpaciente.txt", "rb");
   temp = fopen("tmp.txt", "wb");


   if(CadArquivo == NULL&&temp==NULL){
    printf("ATEN��O !!! Problemas na abertura do registro ou cadastro vazio...\n\n");
    getch();
   }
   else{
        cabecalho();
        fflush(stdin);
        printf("Digite o nome a deletar: ");
        gets(nome);

    while(fread(&pac, sizeof(PACIENTE), 0,CadArquivo) == 1)
        {
            if(strcmp(nome,pac.nome)==0)
            {
                printf("Data Diagnostico: %d/%d/%d \n", pac.dtdiag.diag, pac.dtdiag.mesg, pac.dtdiag.anog);
                printf("Nome: %s\n",pac.nome);
                printf("Data de Nascimento: %d/%d/%d \n", pac.dtnasc.dian, pac.dtnasc.mesn, pac.dtnasc.anon);
                printf("Idade: %s \n",pac.idade);
                printf("Email: %s\n",pac.email);
                printf("CPF: %s\n",pac.cpf);
                printf("Telefone: %s\n",pac.fone);
                printf("Endere�o: %s\n",pac.endereco);
                printf("Bairro: %s\n",pac.bairro);
                printf("CEP: %s\n",pac.cep);
                printf("Cidade: %s\n",pac.cidade);
                printf("UF: %s\n",pac.uf);
                printf("Comorbidades: %s\n",pac.comorbidade);
                printf("\n------------------------------------------------------------\n\n");
            }
            else
            {
               fwrite(&pac,sizeof(PACIENTE),1,temp);
            }
            fclose(CadArquivo);
            fclose(temp);
            fflush(stdin);
            printf("Deseja deletar (s/n)? ");
      if(getche()=='s')
      {
        if(remove("cadpaciente.txt")==0&&rename("tmp.txt","cadpaciente.txt")==0)
            {
                printf("\nOperacao realizada com sucesso!");
            }
        else
            {
                remove("tmp.txt");
            }

      }
        fclose(CadArquivo);
        fclose(temp);
        getch();
    }
   }
}

void PesquisarPac(){

    FILE* CadArquivo;
    PACIENTE pac;
    char nome[30];

   CadArquivo = fopen("cadpaciente.txt", "rb");

   cabecalho();
   if(CadArquivo == NULL){
    printf("ATEN��O !!! Problemas na abertura do registro ou cadastro vazio...\n\n");
   }
   else{
        fflush(stdin);
        printf("Digite o nome a pesquisar: ");
        gets(nome);

    while(fread(&pac, sizeof(PACIENTE), 1,CadArquivo) == 1){
            if(strcmp(nome, pac.nome)==0)

            printf("Data Diagnostico: %d/%d/%d \n", pac.dtdiag.diag, pac.dtdiag.mesg, pac.dtdiag.anog);
            printf("Nome: %s\n",pac.nome);
            printf("Data de Nascimento: %d/%d/%d \n", pac.dtnasc.dian, pac.dtnasc.mesn, pac.dtnasc.anon);
            printf("Idade: %s\n",pac.idade);
            printf("Email: %s\n",pac.email);
            printf("CPF: %s\n",pac.cpf);
            printf("Telefone: %s\n",pac.fone);
            printf("Endere�o: %s\n",pac.endereco);
            printf("Bairro: %s\n",pac.bairro);
            printf("CEP: %s\n",pac.cep);
            printf("Cidade: %s\n",pac.cidade);
            printf("UF: %s\n",pac.uf);
            printf("Comorbidades: %s\n",pac.comorbidade);
            printf("\n------------------------------------------------------------\n\n");
        }

   }
   fclose(CadArquivo);
   getch();

}

void RelatorioRsk(){
    cabecalho();
    printf("\n\tFUN��O EM FASE DE DESENVOLVIMENTO!");
    printf("\n\n\tPRECIONE [ENTER] PARA RETORNAR AO MENU PRINCIPAL. ");
    getch();


}

void Login(){

    cabecalho();

    char login[15] = "pim4";
    char login1[15];
    char senha[15] = "pim4";
    char senha1[15];
    int login_efetuado = 0; //0 - Falso e  1 - Verdadeiro

    while(!login_efetuado){
    printf("Digite o Login: ");
    scanf("%s", login1);

    printf("Digite a Senha: ");
    scanf("%s", senha1);

    if (strcmp(login, login1) == 0 && strcmp(senha, senha1) == 0){

        printf("\n\nACESSO LIBERADO!\n\n");
        login_efetuado = 1;
    }
    else

        printf("\n\nACESSO NEGADO!\n\n");
        getch();
        system("cls");
        cabecalho();
    }
    cabecalho();
}

